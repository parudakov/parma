# scena24-watcher

Следит за новыми событиями на [scena24.ru/v2](https://scena24.ru/v2/) и шлёт их в Telegram через вашего бота.

## Как это работает

1. **Источник.** Сайт защищён ServicePipe (JS-challenge + fingerprint), поэтому сервис открывает его в headless Chromium через Playwright, ждёт рендера React-приложения и забирает JSON со списком событий через встроенный API: `GET https://scena24.ru/api/events`.
2. **Дедупликация.** Локальный `state.json` хранит множество `id` событий, по которым уже отправлено уведомление. При каждом опросе берётся только дельта.
3. **Уведомление.** Сообщения уходят через Telegram Bot API. Каждое содержит название, вид спорта, дату/время, ссылку на событие и постер.
4. **Безопасность HTTP.** Все исходящие запросы проходят через `src/safe_http.py` — только `http`/`https`, allowlist хостов (`scena24.ru`, `api.telegram.org`) и проверка DNS, чтобы запретить loopback / приватные / зарезервированные адреса.

## Схема события

Минимально используемые поля из ответа `/api/events`:

```json
{
  "id": 632,
  "name": "№31 ХК \"Молот\" (г.Пермь) - ХК СКА-ВМФ(г. Санкт-Петербург)",
  "start_date": 1788962400,
  "event_category": "Хоккей",
  "image": "http://scena24.ru/assets/images/events/event_635.png"
}
```

Ссылка на событие — `https://scena24.ru/v2/event/<id>`.

## Установка на Ubuntu

```bash
sudo useradd --system --shell /usr/sbin/nologin --home /opt/scena24-watcher scena24
sudo mkdir -p /opt/scena24-watcher /opt/scena24-watcher/logs
sudo chown -R scena24:scena24 /opt/scena24-watcher

cd /opt/scena24-watcher
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
playwright install --with-deps chromium
cp .env.example .env
sudo chown scena24:scena24 .env
chmod 600 .env
$EDITOR .env      # вписать TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID
```

Скопируйте файлы проекта в `/opt/scena24-watcher` (`src/`, `requirements.txt`, `.env`).

### Вариант 1: cron (раз в 5 минут)

```bash
sudo cp deploy/crontab.example /etc/cron.d/scena24-watcher
sudo chmod 644 /etc/cron.d/scena24-watcher
sudo systemctl restart cron
```

`watcher send` — идемпотентный одноразовый запуск: если новых событий нет, он только обновит `last_check_at` и не будет спамить.

### Вариант 2: systemd (долгий цикл)

```bash
sudo cp deploy/scena24-watcher.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now scena24-watcher
sudo journalctl -u scena24-watcher -f
```

## Проверка вручную

```bash
# Просто увидеть, что отдаёт API (без отправки в Telegram)
python -m watcher check

# Один раз проверить и отправить новые события
python -m watcher send

# Цикл (как в systemd)
python -m watcher run --interval 300
```

## Переменные окружения

| Переменная             | Описание                                                                |
| ---------------------- | ----------------------------------------------------------------------- |
| `TELEGRAM_BOT_TOKEN`   | Токен бота (`@BotFather` → `/token`)                                    |
| `TELEGRAM_CHAT_ID`     | Числовой id чата/канала                                                 |
| `STATE_PATH`           | Путь к `state.json`. По умолчанию `./state.json`                         |
| `POLL_INTERVAL_SEC`    | Интервал опроса для `watcher run`. По умолчанию `300`                    |
| `HEADLESS`             | `1` — без UI, `0` — с окном (только для отладки на десктопе)            |
| `LOG_LEVEL`            | `DEBUG`/`INFO`/`WARNING`/`ERROR`                                        |

## Безопасность

- Все сетевые вызовы — через `safe_http.assert_safe_url`. Любой URL, чей хост не входит в `ALLOWED_HOSTS`, отклоняется. Любой резолв в приватный/loopback/multicast-адрес отклоняется.
- Бот не принимает команды — только отправляет сообщения от вашего имени.
- Токен хранится в `.env` с правами `0600` и подгружается в systemd через `EnvironmentFile=`; для cron используется файл, доступный только пользователю `scena24`.

## Файлы

```
src/
  safe_http.py   # allowlist + проверка IP
  fetcher.py     # Playwright + page-context fetch('/api/events')
  state.py       # state.json: дедупликация
  notifier.py    # Telegram Bot API
  watcher.py     # CLI: check / send / run
deploy/
  scena24-watcher.service  # systemd unit
  crontab.example          # /etc/cron.d/...
requirements.txt
.env.example
```