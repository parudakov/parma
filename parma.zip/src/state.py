"""Локальное состояние — какие события мы уже уведомили.

Файл ``state.json`` лежит в каталоге, указанном через ``STATE_PATH``.
Он хранит:

* ``sent_ids``: множество идентификаторов событий, по которым уже отправили
  уведомление (чтобы не дублировать при повторных запусках);
* ``last_check_at``: ISO-таймштамп последнего успешного опроса.

Использование::

    state = State.load()
    new_ids = state.diff(events)
    ...
    state.mark_sent(ids)
    state.save()
"""
from __future__ import annotations

import json
import logging
import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable

log = logging.getLogger(__name__)


@dataclass
class State:
    sent_ids: set[int] = field(default_factory=set)
    last_check_at: str | None = None

    @classmethod
    def load(cls, path: str) -> "State":
        if not os.path.exists(path):
            return cls()
        try:
            with open(path, "r", encoding="utf-8") as fh:
                raw = json.load(fh)
        except (json.JSONDecodeError, OSError) as exc:
            log.warning("Не удалось прочитать state.json (%s); стартуем с пустого состояния", exc)
            return cls()
        ids = raw.get("sent_ids") or []
        return cls(
            sent_ids={int(x) for x in ids},
            last_check_at=raw.get("last_check_at"),
        )

    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        payload = {
            "sent_ids": sorted(self.sent_ids),
            "last_check_at": self.last_check_at or datetime.now(timezone.utc).isoformat(),
        }
        # Атомарная запись: сначала во временный файл, затем replace.
        fd, tmp = tempfile.mkstemp(prefix=".state.", dir=os.path.dirname(path) or ".")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
        except Exception:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def diff(self, events: Iterable[dict]) -> list[dict]:
        """Возвращает только те события, чей id ещё не помечен как отправленный."""
        return [e for e in events if int(e["id"]) not in self.sent_ids]

    def mark_sent(self, ids: Iterable[int]) -> None:
        self.sent_ids.update(int(x) for x in ids)
        self.last_check_at = datetime.now(timezone.utc).isoformat()