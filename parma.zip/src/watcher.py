"""Точка входа: опрос событий и уведомление в Telegram.

CLI:
    python -m watcher check   # один раз скачать события и напечатать их
    python -m watcher run     # цикл опроса каждые N секунд
    python -m watcher send    # один раз скачать и отправить новые

Конфигурация — через переменные окружения (см. README):
    TELEGRAM_BOT_TOKEN     токен бота
    TELEGRAM_CHAT_ID       id чата/канала
    STATE_PATH         путь к state.json (по умолчанию ./state.json)
    POLL_INTERVAL_SEC интервал опроса (по умолчанию 300)
    HEADLESS           1/0 — показывать ли браузер (по умолчанию 1)
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import sys
import time

# Импорт fetcher откладываем — он тянет Playwright, который нужен только
# для реального сетевого опроса. Так CLI --help и юнит-тесты работают
# на машинах без установленного Chromium.
from state import State
from notifier import TelegramNotifier


def _get_fetcher():
    from fetcher import fetch_events
    return fetch_events

log = logging.getLogger("watcher")


def _load_state() -> State:
    return State.load(path=os.environ.get("STATE_PATH", "state.json"))


def _save_state(state: State) -> None:
    state.save(path=os.environ.get("STATE_PATH", "state.json"))


def _check_once(notify: bool) -> int:
    headless = os.environ.get("HEADLESS", "1") != "0"
    fetch_events = _get_fetcher()
    events = fetch_events(headless=headless)
    log.info("Получено событий: %d", len(events))

    state = _load_state()
    new_events = state.diff(events)
    log.info("Новых (ещё не уведомлённых): %d", len(new_events))

    if notify and new_events:
        token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
        chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
        notifier = TelegramNotifier(token=token, chat_id=chat_id)
        notifier.notify_events(new_events)
        state.mark_sent(e["id"] for e in new_events)
        _save_state(state)
    elif not notify:
        # Режим check: печатаем JSON в машиночитаемом виде для отладки
        json.dump(new_events, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        # Ничего нового — обновим только last_check_at.
        state.last_check_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat()
        _save_state(state)

    return len(new_events)


def cmd_check(_args: argparse.Namespace) -> int:
    n = _check_once(notify=False)
    print(f"Новых событий: {n}", file=sys.stderr)
    return 0


def cmd_send(_args: argparse.Namespace) -> int:
    n = _check_once(notify=True)
    print(f"Отправлено уведомлений: {n}")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    interval = int(os.environ.get("POLL_INTERVAL_SEC", str(args.interval)))
    stop = {"flag": False}

    def _handle_sig(_sig, _frame):
        log.info("Получен сигнал, завершаюсь")
        stop["flag"] = True

    signal.signal(signal.SIGINT, _handle_sig)
    signal.signal(signal.SIGTERM, _handle_sig)

    while not stop["flag"]:
        try:
            _check_once(notify=True)
        except Exception as exc:  # noqa: BLE001
            log.exception("Ошибка при опросе: %s", exc)
        for _ in range(interval):
            if stop["flag"]:
                break
            time.sleep(1)
    return 0


def main(argv: list[str] | None = None) -> int:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    parser = argparse.ArgumentParser(prog="scena24-watcher")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("check", help="одноразовая проверка, печать новых событий в stdout").set_defaults(func=cmd_check)
    sub.add_parser("send", help="одноразовая проверка с отправкой в Telegram").set_defaults(func=cmd_send)
    p_run = sub.add_parser("run", help="цикл опроса с отправкой новых событий")
    p_run.add_argument("--interval", type=int, default=300, help="интервал опроса, сек (по умолчанию 300)")
    p_run.set_defaults(func=cmd_run)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())