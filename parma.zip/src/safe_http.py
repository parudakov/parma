"""Безопасный HTTP: только http/https, allowlist хостов, отказ для приватных адресов."""
from __future__ import annotations

import ipaddress
import socket
from typing import Iterable
from urllib.parse import urlparse

import requests

# Только эти хосты разрешено запрашивать. Пополняйте осознанно.
ALLOWED_HOSTS: set[str] = {
    "scena24.ru",
    "www.scena24.ru",
    "api.telegram.org",
}

REQUEST_TIMEOUT = 15


def _is_forbidden_ip(addr: str) -> bool:
    """True для loopback / private / link-local / multicast / зарезервированных адресов."""
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return True  # невалидный адрес тоже считаем запрещённым

    if ip.is_loopback or ip.is_private or ip.is_link_local:
        return True
    if ip.is_multicast or ip.is_reserved or ip.is_unspecified:
        return True
    # 100.64.0.0/10 (CGNAT) уже попадает под is_private в Python 3.9+, но на всякий случай
    return False


def _resolve_all(host: str) -> list[str]:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as exc:
        raise RuntimeError(f"DNS-резолв для {host} не удался: {exc}") from exc
    return list({i[4][0] for i in infos})


def assert_safe_url(url: str) -> str:
    """Проверяет URL: только http/https, хост в allowlist, DNS не указывает на приватный адрес."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError(f"Запрещённый протокол: {parsed.scheme!r} (допустимы только http/https)")
    host = (parsed.hostname or "").lower()
    if not host:
        raise ValueError("URL без hostname")
    if host not in ALLOWED_HOSTS:
        raise ValueError(f"Хост {host!r} не в allowlist")
    for addr in _resolve_all(host):
        if _is_forbidden_ip(addr):
            raise ValueError(f"Хост {host!r} резолвится в запрещённый адрес {addr}")
    return url


def safe_get(url: str, *, headers: dict | None = None, timeout: int = REQUEST_TIMEOUT) -> requests.Response:
    assert_safe_url(url)
    resp = requests.get(url, headers=headers or {}, timeout=timeout)
    resp.raise_for_status()
    return resp


def safe_post_json(url: str, payload: dict, *, timeout: int = REQUEST_TIMEOUT) -> requests.Response:
    assert_safe_url(url)
    resp = requests.post(url, json=payload, timeout=timeout)
    resp.raise_for_status()
    return resp


def check_scena24_url() -> str:
    """Готовая ссылка на событие на сайте (для формирования уведомлений)."""
    return "https://scena24.ru"