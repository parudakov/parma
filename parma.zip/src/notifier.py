"""Отправка уведомлений в Telegram через Bot API.

Только разрешённые хосты (``api.telegram.org``) — реализовано в ``safe_http``.
URL события формируется как ``https://scena24.ru/v2/event/<id>``.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Iterable

from safe_http import safe_post_json, assert_safe_url

log = logging.getLogger(__name__)

API_BASE = "https://api.telegram.org/bot{token}/sendMessage"


def _format_event(event: dict) -> str:
    eid = event["id"]
    name = event.get("name") or "(без названия)"
    category = event.get("event_category") or ""
    start_ts = event.get("start_date")
    when = ""
    if isinstance(start_ts, (int, float)):
        dt = datetime.fromtimestamp(start_ts, tz=timezone.utc).astimezone()
        when = dt.strftime("%d.%m.%Y %H:%M")
    image = event.get("image") or ""

    lines = [f"🏟 *Новое событие на Сцена24*", f"*{name}*"]
    if category:
        lines.append(f"Вид спорта: {category}")
    if when:
        lines.append(f"Когда: {when} (по местному времени сервера)")
    # Ссылку собираем через разрешённый хост — дополнительная проверка внутри safe_http.
    link = f"https://scena24.ru/v2/event/{eid}"
    assert_safe_url(link)
    lines.append(f"[Открыть событие]({link})")
    if image:
        lines.append(f"Постер: {image}")
    return "\n".join(lines)


class TelegramNotifier:
    def __init__(self, token: str, chat_id: str, *, parse_mode: str = "Markdown") -> None:
        if not token or not chat_id:
            raise ValueError("TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID должны быть заданы")
        self._url = API_BASE.format(token=token)
        # Заодно прогоняем итоговый URL через guard.
        assert_safe_url(self._url)
        self._chat_id = chat_id
        self._parse_mode = parse_mode

    def send(self, text: str) -> None:
        resp = safe_post_json(
            self._url,
            payload={
                "chat_id": self._chat_id,
                "text": text,
                "parse_mode": self._parse_mode,
                "disable_web_page_preview": False,
            },
        )
        log.info("Telegram: HTTP %s, ответ %s", resp.status_code, resp.text[:200])

    def notify_events(self, events: Iterable[dict]) -> None:
        for event in events:
            try:
                self.send(_format_event(event))
            except Exception as exc:
                log.exception("Не удалось отправить уведомление по событию %s: %s", event.get("id"), exc)